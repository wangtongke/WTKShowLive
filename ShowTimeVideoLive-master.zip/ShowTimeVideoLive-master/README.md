# ShowTimeVideoLive
仿映客视频直播和推流
本demo涉及到视频采集推流，所以只适用于真机。
由于GitHub不允许上传大于100M文件，所以你可以在链接: http://pan.baidu.com/s/1kUT7ClL，密码:6uji ，下载B站的IJKMediaFramework.framework文件拖入到项目中运行即可，或到简书合并框架后导入到项目中即可地址http://www.jianshu.com/p/1f06b27b3ac0
